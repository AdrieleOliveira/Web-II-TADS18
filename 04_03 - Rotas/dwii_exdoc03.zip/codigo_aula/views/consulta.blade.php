<h2>Lista de Consultas</h2>
<a href="{{route('consulta.agendar')}}">Agendar</a>
<br>
<a href="{{route('consulta.cancelar')}}">Cancelar</a>

