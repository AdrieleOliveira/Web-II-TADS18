<html lang="pt-br">
    <head>
        <title> Formulário - POST </title>
        <meta charset="utf-8">
    </head>
    <body>
        <form action="trata_post.php" method="post">
            <p> Aluno: <input type="text" name="aluno"/> </p>
            <p> Turma: <input type="text" name="turma"/> </p>
            <p> <input type="submit" value="Enviar!"/> </p>
        </form>
    </body>
</html>


