<?php

	function funcConsts() {
		echo "ARQUIVO: ".__FILE__."<br>"; 
		echo "DIRETÓRIO: ".__DIR__."<br>"; 
		echo "LINHA: ".__LINE__."<br>"; 
		echo "FUNÇÃO: ".__FUNCTION__."<br>"; 
	} 

	funcConsts();
?>


