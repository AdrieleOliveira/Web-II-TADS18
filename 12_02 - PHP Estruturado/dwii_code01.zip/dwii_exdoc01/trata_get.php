<?php
	echo $_GET['aluno'];
	echo "<br>";
	echo $_GET['turma'];
?>

