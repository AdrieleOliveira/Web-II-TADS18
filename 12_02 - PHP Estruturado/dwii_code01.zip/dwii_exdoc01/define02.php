<?php

	define("PI", 3.1415, true);
	echo PI;
?>


