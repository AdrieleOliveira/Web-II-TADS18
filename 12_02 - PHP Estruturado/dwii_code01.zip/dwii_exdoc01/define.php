<?php

	define("PI", 3.1415);
	echo PI;
?>


