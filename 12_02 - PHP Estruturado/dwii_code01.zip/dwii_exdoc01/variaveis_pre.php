<?php
	$vars_pre = get_defined_vars();
	print_r($vars_pre);
?>


