<?php
	
	$v1;
	$v2=12;
	if(isset($v1)) { echo "A variável \$v1 FOI inicializada!"; }
	else { echo "A variável \$v1 NÃO FOI inicializada!"; }

	echo "<br><br>";

	if(isset($v2)) { echo "A variável \$v2 FOI inicializada!"; }
	else { echo "A variável \$v2 NÃO FOI inicializada!"; }

?>


