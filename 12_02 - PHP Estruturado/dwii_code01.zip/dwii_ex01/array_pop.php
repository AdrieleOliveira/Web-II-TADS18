<?php
	
	$modelos = array("gol", "up");
	array_push($modelos, "jetta", "golf");

	echo "MODELOS: ";
	for($a=0; $a<count($modelos); $a++) {
		echo "$modelos[$a] ";
	}
?>


